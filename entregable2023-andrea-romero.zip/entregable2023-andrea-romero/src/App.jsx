import Formulario from "./components/Formulario";

function App() {
  return (
    <div className="App">
      <Formulario />
    </div>
  );
}

export default App;
