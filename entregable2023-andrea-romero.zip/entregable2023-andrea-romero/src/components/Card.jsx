import styles from './Card.style.css'
// eslint-disable-next-line react/prop-types
const Card = ({name, heroe}) => {
  return (
    <div className={styles.container}>
      <div><h2>Hola {name}!</h2></div>
      <div><p className={styles.text}>Tu HEROE elegido es {heroe}!</p></div>
    </div>
  );
}

export default Card;