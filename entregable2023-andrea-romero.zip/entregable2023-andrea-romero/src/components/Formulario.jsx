import { useState } from "react";
import Card from './Card'
import styles from './Formulario.style.css'

function Formulario() {

    //UseState
    const [name, setName] = useState("");
    const [heroe, setHeroe] = useState("");
    const [error, setError] = useState("");
    const [showCard, setShowCard] = useState(false);

    const onChangeName = (e) => setName(e.target.value);
    const onChangeHeroe = (e) => setHeroe(e.target.value)

    const validateInputName = () => {return name.trim().length >= 3};
    const validateInputHeroe = () => {return heroe.length >= 6};

    const handleOnChange = (e) => {
        e.preventDefault();

        const validatedInputName = validateInputName()
        const validatedInputHeroe = validateInputHeroe()
        
        if(validatedInputName && validatedInputHeroe) {
            setShowCard(true);
            setError("");
        } else {
            setShowCard(false);
            setError("Por favor chequea que la información sea correcta.");
        }
    }

    return (
        <div className={styles.container}>
            <h1>Completa los datos:</h1>
            <div className={styles.formContainer}>
                <form onSubmit={handleOnChange}>
                    <div>
                    <label>Ingresa tu nombre:</label>
                        <input type="text" value={name} onChange={onChangeName}/>
                    </div>
                    <div>
                    <label>Ingresa el nombre de tu Heroe favorito:</label>
                        <input type="text" value={heroe} onChange={onChangeHeroe}/>
                    </div>
                    <button type="submit">Enviar</button>
                </form>
            </div>
            {error ? <div className={styles.error}>{error}</div> : null}
            {showCard ? <Card name={name} heroe={heroe}/> : null}
        </div>
    );
}

export default Formulario;